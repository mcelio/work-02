package org.crossover.client;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "file:src/main/webapp/WEB-INF/applicationContext.xml",
		"file:src/main/webapp/WEB-INF/beans.xml" })
public class ClientTest {

	static final Logger logger = LogManager.getLogger(ClientTest.class.getName());

	
	@Test
	public void loginTest(){
		
		String username = "ADMIN", password = "ADMINPASS";
		
		Assert.assertEquals(username, "ADMIN");		
		Assert.assertEquals(password, "ADMINPASS");
		
	}
}
