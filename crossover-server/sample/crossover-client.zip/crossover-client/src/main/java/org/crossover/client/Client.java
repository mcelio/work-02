package org.crossover.client;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Date;

import org.crossover.client.ws.Compilation;
import org.crossover.client.ws.CompileService;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;

public class Client {

	public static void main(String args[]) throws Exception {

		JaxWsPortProxyFactoryBean factory = new JaxWsPortProxyFactoryBean();
		factory.setEndpointAddress("http://localhost:8080/CxfService/UploadWS");
		CompileService client = (CompileService) factory.createJaxWsService(); 
		Compilation compilation = new Compilation();
		String fileName = "";
		RandomAccessFile f = new RandomAccessFile(fileName, "r");
		byte[] b = new byte[(int)f.length()];
		f.read(b);		
		compilation.setFile(b);
		compilation.setDate(new Date().toString());
		client.compile(compilation);
		

		File file = new File("D:/my_upload_doc.doc");		

	}

}
