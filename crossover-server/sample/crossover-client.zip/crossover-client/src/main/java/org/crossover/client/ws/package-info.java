@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.server.crossover.org/")
package org.crossover.client.ws;
