package org.crossover.client;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
 
@ManagedBean
@SessionScoped
public class ClientBean implements Serializable {
 
	private static final long serialVersionUID = 1L;
	
	// Console logger
	static final Logger logger = LogManager.getLogger(ClientBean.class.getName());
	
	private String name;
 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getList() {
		try{	
			return "ok";
		}catch(Exception e){
			logger.error("Error: ", e);	
			return null;
		}
		
	}
	
}
